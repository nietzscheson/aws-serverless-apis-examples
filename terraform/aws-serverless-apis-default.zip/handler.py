def handler(event, context):
    result = "Hello from the handler!"

    # Define CORS headers
    # cors_headers = {
    #     'Access-Control-Allow-Origin': '*',  # Allows access from any origin
    #     'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',  # Allowed request methods
    #     'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'  # Allowed request headers
    # }

    # Include the CORS headers in the response
    return {
        'statusCode': 200,
        'body': result,
        #'headers': cors_headers
    }
